#ifndef MM_H
#define MM_H

#include <types.h>

typedef struct
{
    
    
} heap_t;

void* kmalloc(uint32_t size);
void mm_init();

#endif