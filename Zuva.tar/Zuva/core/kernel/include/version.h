#ifndef VERSION_H
#define VERSION_H

#define VER_MAJOR 	0
#define VER_MINOR 	1
#define VER_BUILD_NO 	0

#endif