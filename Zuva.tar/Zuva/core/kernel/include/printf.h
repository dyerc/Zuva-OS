#ifndef PRINTF_H
#define PRINTF_H

void kprintf(const char *msg, ...);

#endif