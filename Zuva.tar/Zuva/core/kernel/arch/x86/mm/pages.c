/* 
 * page.c - The architecture initialisation point for paging on
 * x86 (i386).
 * 
 * 
 * This file is part of the Zuva Operating System. 
 * 
 * (C) Copyright Chris Dyer & Zuvium 2009 - 2010. Do Not Re-distribute. 
 * For internal viewing only.
 * 
 */

#include <types.h>
#include <arch/x86.h>
#include <utils.h>

uint64_t memory_size = 0;
mm_page_t* memory_pages;
mm_description_t memory_descriptors[MAX_MEMORY_TYPES];

mm_description_t* arch_pages_get_descriptor(void* address)
{
	mm_description_t* descriptor;
	uint32_t i;
	
	for (i = 0; i < MAX_MEM_TYPES; i++)
	{
		descriptor = &memory_descriptors[i];
		
		// TODO: Could be wrong :/
		if (descriptor->start <= address && address < (descriptor->start + descriptor->size))
			return descriptor;
	}
	
	return NULL;
}

// TODO: Cleanup up type as int into an enum
void* arch_pages_alloc(uint32_t count, uint32_t type)
{
}

void arch_pages_reserve(uint64_t start, uint64_t size)
{
	uint32_t page_count = size / PAGE_SIZE;
	uint32_t page_start_index = start / PAGE_SIZE;
	
	uint32_t i;
	for (i = page_start_index; i < pages_start_index + page_count; i++)
	{
		if (memory_pages[i].ref_count == 0)
			memory_pages[i].ref_count++;
	} 
}

void arch_pages_init(uint64_t start, uint64_t _memory_size)
{
	uint32_t i;
	for (i = 0; i < MAX_MEM_TYPES; i++)
	{
	}
	
	memory_size = _memory_size;
	memory_pages = (mm_page_t*)start;
	uint32_t page_count = memory_size / PAGE_SIZE;
	
	memset((void*)memory_pages, 0, sizeof(mm_page_t) * page_count);
}
