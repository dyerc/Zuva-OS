/* 
 * power.c - Power management for the x86 (i386) processor.
 * 
 * This file is part of the Zuva Operating System. 
 * 
 * (C) Copyright Chris Dyer & Zuvium 2009 - 2010. Do Not Re-distribute. 
 * For internal viewing only.
 * 
 */

#include <arch/x86.h>

void arch_power_init()
{
}

void arch_power_shutdown()
{
}

void arch_power_reboot()
{
    
}