/* 
 * rtc.c - The architecture independent memory manager.
 * 
 * 
 * This file is part of the Zuva Operating System. 
 * 
 * (C) Copyright Chris Dyer & Zuvium 2009 - 2010. Do Not Re-distribute. 
 * For internal viewing only.
 * 
 */

#include <types.h>
#include <mm.h>

extern uint32_t end;
uint32_t free_mem_start = (uint32_t)&end;
uint32_t free_mem_end;

bool setup = 0;

void* kmalloc(uint32_t size)
{
    void* ptr;
    
    // The memory manager is not yet installed
    if (setup == 0)
    {
	ptr = (void*)free_mem_start;
	free_mem_start += size;
    }
    else
    {
	// Allocate some room from the heap
    }
    
    return ptr;
}

void mm_init()
{
}